#!/bin/bash
read -p "please input a num:" NUM

if [ $NUM -lt 5 ];then
	echo "lt"
elif [ $NUM -eq 5 ];then
	echo "eq"
else
	echo "gt"
fi
