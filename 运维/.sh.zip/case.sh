redhat(){
	echo centos
	return 0
}
centos(){
	echo redhat
	return 0
}
case $1 in
centos)
	centos
;;
redhat)
	redhat
;;
*)
	echo "usage case.sh {redhat|centos}"
esac
