#!/bin/bash
read -p "please input ip:" IP

if `ping -c2 -i0.2 -W2 $IP &> /dev/null` ;then
	echo "$IP is up"
else
	echo "$IP is down"
fi

