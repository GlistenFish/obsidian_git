#!/bin/bash
for i in {1..10};do
	echo "hello $i"
done
